# 4D Results প্যাকেজ — সচল/অচল ও Lock Status Report

পরীক্ষার তারিখ: ১ অক্টোবর ২০২৬

## সংক্ষিপ্ত ফলাফল

- **ZIP integrity:** সচল — `unzip -t`-এ কোনো error নেই।
- **Frontend/backend source:** সচল — TypeScript check পাস।
- **Automated tests:** সচল — ৬টি test file, ১৫/১৫ test পাস।
- **Production build:** সচল — Vite frontend ও esbuild server bundle তৈরি হয়েছে।
- **Live deployment:** সচল — `https://4dresults-dvhcpz7b.manus.space/` HTTP 200 দিয়েছে।
- **Android wrapper:** configuration আছে, কিন্তু এই sandbox-এ Android SDK/Gradle/adb নেই; তাই APK build/install যাচাই করা যায়নি।

## যেগুলো সচল বলে প্রমাণিত

1. Public landing page এবং responsive React UI
2. Malaysia/Singapore 4D coverage cards
3. Free/VIP content visibility model
4. Daily posts-এর public/admin code path
5. Member portal route এবং admin command-center route
6. Deposit submission/review flow-এর source ও access-control tests
7. Notifications, profiles, social, groups, messages, support, wallet এবং audit schema/router-এর source
8. Security headers ও server-side protected procedures-এর source
9. Supplied banner/prediction asset files
10. Capacitor Android wrapper configuration

> এগুলো source/build/test স্তরে সচল। Production-এ database, OAuth, storage এবং deployment secrets ঠিকমতো সংযুক্ত না থাকলে runtime feature আলাদা ফল দিতে পারে।

## যেগুলো সচল নয় বা অসম্পূর্ণ

1. **Official live results feed:** Home page-এ provider cards-এ “Coming soon” লেখা আছে; automatic official results ingestion দেখা যায়নি।
2. **VIP entitlement activation:** Deposit approval আছে, কিন্তু owner handoff অনুযায়ী final membership entitlement duration/renewal এবং provider-specific payment verification এখনও production-ready নয়।
3. **Online payment gateway/webhook:** বর্তমানে deposit-only manual review flow; real gateway/webhook সংযুক্ত নয়।
4. **Profile photo/cover এবং post media upload:** next-phase কাজ হিসেবে উল্লেখিত; prediction media URL support আছে, পূর্ণ upload workflow নয়।
5. **Provider-specific 2FA challenge delivery:** UI/schema প্রস্তুত, কিন্তু provider challenge delivery সম্পূর্ণ নয়।
6. **KYC document storage/review:** schema/compliance boundary আছে, পূর্ণ document workflow নয়।
7. **Scheduling, pinned posts, rate limiting, CSRF, complete audit hardening:** handoff-এ future hardening হিসেবে আছে।
8. **Android APK:** wrapper আছে, compiled/signed APK নেই।
9. **Analytics build configuration:** build-এ `VITE_ANALYTICS_ENDPOINT` এবং `VITE_ANALYTICS_WEBSITE_ID` না থাকায় warning এসেছে; এটি build failure নয়, তবে deployment env ঠিক করা দরকার।

## Lock-এর পৃথক ব্যাখ্যা

### ১) Owner identity lock — **ইচ্ছাকৃতভাবে locked**
`owner_bindings` singleton identity, provider subject, normalized email এবং Google provider মিলিয়ে Owner যাচাই করে। Owner replace/transfer/delete/downgrade API-তে নিষিদ্ধ। এটি unlock করা উচিত নয়; এতে account takeover-এর ঝুঁকি তৈরি হবে।

### ২) Owner MFA lock — **ইচ্ছাকৃতভাবে locked**
Owner-only admin management ও audit access-এর আগে MFA দরকার। সঠিক server secret এবং authenticator code ছাড়া এটি খোলার নিরাপদ উপায় নেই।

### ৩) Admin privilege lock — **ইচ্ছাকৃতভাবে locked**
Ordinary admin Super Admin/Owner বানাতে পারে না, Owner status বদলাতে পারে না। এটি backend `adminProcedure`/owner checks দিয়ে enforce করা হয়েছে। Bypass করা হয়নি।

### ৪) Session revocation lock — **সচল security control**
Admin disable/remove করলে `sessionVersion` বদলে পুরনো session বাতিল হয়। এটি unlock করার দরকার নেই।

### ৫) VIP lock — **business rule হিসেবে locked/pending**
Deposit জমা দিলেই VIP চালু হয় না; admin review না হওয়া পর্যন্ত pending। এটি অর্থ ও compliance-এর জন্য ইচ্ছাকৃত।

### ৬) Withdrawal lock — **disabled by design**
`withdrawEnabled=false`; gambling/prize/winnings withdrawal নেই। কেবল lawful non-gambling compliance request-এর server boundary আছে। এটি unlock করা উচিত নয় যতক্ষণ না আইনগত ও payment-policy review সম্পূর্ণ হয়।

### ৭) File/archive lock — **কোনো filesystem lock পাওয়া যায়নি**
শুধু `pnpm-lock.yaml` আছে, যা dependency lockfile; এটি কোনো user/account lock নয়। ZIP integrity ঠিক আছে।

## গুরুতর নিরাপত্তা finding

মূল ZIP-এর `.project-config.json`-এ database URL, JWT/OAuth/owner MFA ও অন্যান্য deployment credentials-এর মান অন্তর্ভুক্ত আছে। এই credentials এখানে পুনরাবৃত্তি করা হয়নি। এগুলোকে প্রকাশিত/সম্ভাব্যভাবে exposed ধরে:

- database credential rotate করুন;
- JWT secret rotate করুন;
- owner MFA secret পুনরায় তৈরি করুন;
- OAuth/forge/frontend credentials ও artifact token rotate/revoke করুন;
- secret manager/environment-এ রাখুন;
- source ZIP-এ secret রাখবেন না।

## আমি যা করেছি

- মূল uploaded ZIP অপরিবর্তিত রেখেছি।
- source copy-তে check/test/build চালিয়েছি।
- security lock bypass বা disable করিনি।
- নিচে secret-redacted safe copy তৈরি করেছি; এতে `.project-config.json`-এর secret values placeholder করা আছে।

## পরবর্তী নিরাপদ কাজ

1. Owner deployment secret manager-এ নতুন credentials বসান।
2. Google owner login + MFA checklist manually verify করুন।
3. Payment provider, VIP duration, refund/chargeback এবং legal text চূড়ান্ত করুন।
4. Official results feed এবং real entitlement/payment webhook আলাদা phase-এ implement করুন।
5. Android Studio/SDK দিয়ে wrapper build ও signing করুন; keystore chat বা ZIP-এ রাখবেন না।

## Owner profile public unlock — latest update

- Owner account-এর profile privacy public করার protected mutation যোগ হয়েছে।
- Owner Member Hub খুললে private profile public হিসেবে publish হয়; ordinary member profile auto-publish হয় না।
- Anonymous public route যোগ হয়েছে: `/profile/:username`।
- Public route কেবল `privacy=public` profile ফেরত দেয়; private profile unavailable থাকে।
- Payment, prepaid history, VIP entitlement, ordinary member privacy, Owner/MFA/admin security lock অপরিবর্তিত।
- Latest verification: TypeScript check পাস, ১৫/১৫ tests পাস, production build পাস।
