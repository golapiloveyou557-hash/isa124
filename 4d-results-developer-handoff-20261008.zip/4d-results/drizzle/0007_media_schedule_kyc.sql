ALTER TABLE `daily_posts` ADD `scheduledAt` timestamp;
--> statement-breakpoint
ALTER TABLE `daily_posts` ADD `isPinned` boolean NOT NULL DEFAULT false;
--> statement-breakpoint
ALTER TABLE `kyc_verifications` ADD `documentUrl` varchar(500);
