# 4D Results managed website plan

## Outcome

Publish the existing tested 4D Results | Malaysia & Singapore full-stack website as a Manus-managed website using the imported React/Vite frontend and Express/Drizzle backend.

## Product scope

- Public landing page with Malaysia and Singapore coverage cards, free/VIP content model, daily posts, responsive black/gold/red visual design and supplied assets.
- Authenticated member portal for profiles, community, groups, messages, membership, wallet, notifications, support, KYC submission and media upload.
- Admin pages for daily posts, deposits, Owner/admin controls and KYC compliance review.
- Owner public profile route `/profile/:username`; only profiles with `privacy=public` are returned anonymously. Owner identity, MFA, admin privilege, session revocation, private data, payment review and non-gambling withdrawal boundaries remain protected.
- Media upload validation, scheduled/pinned daily posts and the existing KYC migration/router/UI changes from the verified source copy.

## Serving and deployment

Use the existing browser-rendered SPA plus Express API arrangement. Build output is `dist/public`; the server bundle is `dist/index.js`. Dynamic `/api/*`, OAuth and storage paths reach the application server. Static assets are served from the built frontend with SPA fallback for browser routes. API and personalized responses remain `no-store`; hashed assets may be immutable.

## Explicit incomplete boundaries

Do not claim or fabricate an official live results provider, real payment gateway/webhook, automatic VIP entitlement, provider-specific 2FA delivery, compiled Android APK, or production secrets. Those remain future configuration phases documented in the Bengali status report.

## Structure

- `client/`: Vite/React UI, pages, components and styles.
- `server/`: Express entrypoint, tRPC routers, database helpers and auth/storage boundaries.
- `drizzle/`: schema and migrations, including media/schedule/KYC migration.
- `shared/`: site and payment configuration plus shared types.
- `assets/` and `android-wrapper/`: supplied visual assets and wrapper configuration.

## Verification

Run dependency installation, TypeScript check, existing Vitest suite and production build. Start the managed Preview on port 3000 and verify representative public, profile, API and SPA-fallback paths without exposing secrets. Save a canonical checkpoint before publish; publish only the saved checkpoint.
