import { Link, useRoute } from "wouter";
import { Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function PublicProfile() {
  const [, params] = useRoute("/profile/:username");
  const profileQuery = trpc.profile.public.useQuery({ username: params?.username ?? "" }, { enabled: Boolean(params?.username) });
  if (profileQuery.isLoading) return <div className="flex min-h-screen items-center justify-center bg-[#070707] text-[#f5bf45]"><Loader2 className="animate-spin" /></div>;
  const profile = profileQuery.data;
  if (!profile) return <div className="flex min-h-screen items-center justify-center bg-[#070707] px-6 text-center text-white"><div><h1 className="font-display text-4xl font-bold">Profile unavailable</h1><p className="mt-3 text-[#a79f89]">This profile is private or does not exist.</p><Link href="/" className="button-red mt-6">Return home</Link></div></div>;
  return <main className="min-h-screen bg-[#070707] px-4 py-10 text-white md:px-8"><div className="mx-auto max-w-3xl"><Link href="/" className="text-sm text-[#f5bf45]">4D Results</Link><section className="portal-card mt-6"><div className="profile-cover">{profile.coverUrl && <img src={profile.coverUrl} alt="" className="h-full w-full object-cover" />}<div className="profile-avatar">{profile.username.slice(0, 1).toUpperCase()}</div></div><div className="mt-12"><div className="eyebrow">Public profile</div><h1 className="font-display mt-2 text-4xl font-bold">@{profile.username}</h1><p className="mt-4 leading-7 text-[#c8c0b5]">{profile.bio || "A member of the 4D Results community."}</p>{profile.location && <p className="mt-3 text-sm text-[#9f9689]">{profile.location}</p>}{profile.website && <a className="mt-4 inline-block text-[#f5bf45] hover:underline" href={profile.website} target="_blank" rel="noreferrer">Visit website</a>}</div></section></div></main>;
}
